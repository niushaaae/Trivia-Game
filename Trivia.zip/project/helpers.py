import sqlite3
from flask import g

# Name of the SQLite database file
DATABASE = "trivia.db"

def get_db():
    """
    Opens a new database connection if there is none yet for the
    current application context, and stores it in Flask's 'g' object.
    Uses Row factory to allow accessing columns by name.
    """
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(exception=None):
    """
    Closes the database connection for the current context if it exists.
    This should be called automatically when the application context ends.
    """
    db = g.pop("db", None)
    if db is not None:
        db.close()

def add_user(name):
    """
    Adds a new user to the 'users' table in the database.

    Args:
        name (str): The name of the user to add.

    Returns:
        int: The ID of the newly inserted user.
    """
    db = get_db()
    cursor = db.cursor()
    cursor.execute("INSERT INTO users (name) VALUES (?)", (name,))
    db.commit()
    return cursor.lastrowid

def get_all_users():
    """
    Retrieves all users from the 'users' table.

    Returns:
        list: A list of sqlite3.Row objects representing each user.
    """
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users")
    return cursor.fetchall()

def get_questions_by_category(category):
    """
    Retrieves all trivia questions for a specific category.

    Args:
        category (str): The category of questions to retrieve.

    Returns:
        list: A list of dictionaries, each containing question text,
              options, and the correct answer.
    """
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        SELECT question, option_a, option_b, option_c, option_d, correct_option
        FROM questions
        WHERE category = ?
    """, (category,))
    rows = cursor.fetchall()

    questions = []
    for row in rows:
        questions.append({
            'question_text': row['question'],
            'option1': row['option_a'],
            'option2': row['option_b'],
            'option3': row['option_c'],
            'option4': row['option_d'],
            'correct_option': row['correct_option']
        })
    return questions
