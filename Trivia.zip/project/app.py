from flask import Flask, render_template, request, session, redirect, url_for
from helpers import get_db, close_db, add_user, get_questions_by_category

app = Flask(__name__)
app.secret_key = "supersecretkey"  # Required for using sessions

@app.teardown_appcontext
def teardown(exception):
    """
    Automatically closes the database connection
    when the application context ends.
    """
    close_db(exception)

# Home page
@app.route("/")
def home():
    """
    Renders the home page where the user can enter their name.
    """
    return render_template("index.html")

# Handle user name submission
@app.route("/greet", methods=["POST"])
def greet():
    """
    Stores the user's name in the database and session,
    then redirects to the category selection page.
    """
    name = request.form.get("fname")
    user_id = add_user(name)

    # Save user information in the session
    session['user_name'] = name
    session['user_id'] = user_id
    return render_template("category.html", name=name)

# Start the quiz after category selection
@app.route("/quiz", methods=["POST"])
def quiz():
    """
    Starts the quiz by retrieving questions for the chosen category.
    Initializes session values for tracking progress and score.
    """
    category = request.form.get("category")
    questions = get_questions_by_category(category)

    if not questions:
        return "No questions available for this category."

    # Save quiz state in the session
    session['questions'] = questions
    session['current_index'] = 0
    session['score'] = 0
    session['category'] = category

    # Show the first question
    question = questions[0]
    return render_template(
        "quiz.html",
        category=category,
        score=0,
        current_index=0,
        question=question
    )

# Handle answer submission and load next question
@app.route("/next", methods=["POST"])
def next_question():
    """
    Processes the user's answer, updates score,
    and moves to the next question or the result page.
    """
    if 'questions' not in session:
        return redirect(url_for('home'))

    selected_answer = request.form.get("answer")
    index = session.get('current_index', 0)
    score = session.get('score', 0)
    questions = session.get('questions', [])

    current_question = questions[index]

    # Check if the selected answer is correct
    if selected_answer and selected_answer.upper() == current_question['correct_option'].upper():
        score += 1

    # Update session progress
    index += 1
    session['score'] = score
    session['current_index'] = index

    # If quiz is finished, render result page
    if index >= len(questions):
        return render_template(
            "result.html",
            user_name=session.get('user_name', 'Player'),
            score=score,
            total=len(questions),
            category=session.get('category', 'Unknown')
        )

    # Otherwise, render the next question
    next_q = questions[index]
    return render_template(
        "quiz.html",
        category=session.get('category', 'Unknown'),
        score=score,
        current_index=index,
        question=next_q
    )

if __name__ == "__main__":
    app.run(debug=True)
