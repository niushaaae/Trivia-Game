# Trivia Game
#### Video Demo:  <https://youtu.be/1Cp4GLJph2E?si=vnzGmLBhhG1sV1Gx>
#### Description:
📌 Full Project Explanation

This project is a Flask-based Trivia Quiz Web Application that combines Python (Flask, SQLite), HTML, CSS, and Jinja templating to create an interactive quiz game. The application allows users to register with their name, choose a quiz category, answer multiple-choice questions, and view their results at the end. Below is a breakdown of each part of the project:


---

1. Backend (Flask & SQLite)

Flask framework is used to handle routing, sessions, and rendering HTML templates.

SQLite database (trivia.db) stores user information and quiz questions.

A helper module (helpers.py) manages database connections and provides functions for common operations:

get_db() → Opens a database connection.

close_db() → Closes the database connection after each request.

add_user(name) → Inserts a new user into the users table.

get_all_users() → Fetches all registered users.

get_questions_by_category(category) → Retrieves all quiz questions for a chosen category.




---

2. Application Logic (app.py)

Home Route (/) → Renders the homepage (index.html) where users can enter their name.

Greet Route (/greet) → Saves the entered name in the database and session, then directs the user to the category selection page (category.html).

Quiz Route (/quiz) →

Loads all questions from the chosen category.

Initializes session variables for progress (current_index) and score (score).

Displays the first question in quiz.html.


Next Route (/next) →

Checks the user’s selected answer against the correct answer.

Updates the score if the answer is correct.

Moves to the next question, or if the quiz is finished, shows the result page (result.html).



✅ Session management ensures that user progress and score are preserved across requests.


---

3. Templates (HTML + Jinja2)

The frontend is built with HTML templates enhanced by Jinja2, allowing dynamic data rendering.

index.html → Homepage where users enter their name.

category.html → Page where users choose the quiz category (e.g., History, Politics, Arts).

quiz.html → Displays the current question, multiple-choice options, and score.

result.html → Shows the final results: category, score, and total number of questions.


Templates are styled consistently and use placeholders ({{ variable }}) to inject dynamic data from Flask.


---

4. Styling (styles.css)

A dedicated CSS stylesheet gives the app a modern, polished look:

Gradient background with centered layout using Flexbox.

Containers (quiz-container, result-container) styled with rounded corners, shadows, and transparency.

Custom radio buttons styled as large clickable buttons with hover and selected states.

Responsive buttons with hover effects and animations.

Result page styling for clear visibility of user’s score and category.



---

5. User Flow (Step by Step)

1. User visits homepage → Enters their name.


2. User selects a category → Chooses from predefined quiz categories.


3. Quiz begins → User answers questions one by one.


4. System checks answers → Updates score in real-time.


5. End of quiz → User sees a result summary with score and total questions.




---

6. Technologies & Skills Demonstrated

Python (Flask) → Web framework, routing, session management.

SQLite → Lightweight database for storing users and questions.

HTML5 & Jinja2 → Dynamic templates with injected server-side data.

CSS3 (Flexbox, transitions, hover effects) → Responsive, modern UI styling.

Clean Code Practices → Modular helper functions, comments, and maintainable structure.



---

✅ In short, this project demonstrates full-stack development skills (backend, frontend, database, and integration) in a small but complete application.


---
